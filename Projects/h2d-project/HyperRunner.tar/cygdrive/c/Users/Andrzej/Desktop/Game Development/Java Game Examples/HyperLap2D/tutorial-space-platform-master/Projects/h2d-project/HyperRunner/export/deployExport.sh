
cp -rf /cygdrive/c/Users/Andrzej/Desktop/Game\ Development/Java\ Game\ Examples/HyperLap2D/tutorial-space-platform-master/Projects/h2d-project/HyperRunner/export/* /cygdrive/c/Users/Andrzej/Desktop/Game\ Development/Java\ Game\ Examples/HyperLap2D/tutorial-space-platform-master/assets


